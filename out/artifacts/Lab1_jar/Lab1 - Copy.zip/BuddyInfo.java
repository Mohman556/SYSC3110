public class BuddyInfo {

    private String name;

    public BuddyInfo(String name){
        this.name = name;

    }

    public BuddyInfo(){
        name = "Homer";
    }

    public static void main(String[] args) {
        BuddyInfo b = new BuddyInfo();
        System.out.println("Hello " + b.getName());
    }

    public String getName() {
        return name;
    }
}
